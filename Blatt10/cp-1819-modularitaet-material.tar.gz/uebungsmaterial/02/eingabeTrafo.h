#ifndef EINGABETRAFO_H__
#define EINGABETRAFO_H__

// Entscheidet, ob an der gegebenen Koordinate ein Zeichen geprintet werden soll
// 1: true
// 0: false
int checkLocationPrint(int, int, int, int);

#endif /* end of include guard: EINGABETRAFO_H__ */
