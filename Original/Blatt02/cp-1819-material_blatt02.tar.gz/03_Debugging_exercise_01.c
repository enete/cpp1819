#include <stdio.h>

void 0OO00O(int eingabe)
{
	return eingabe*eingabe;
}

char testfunktion00()
{
	char output = 'A';
	printf("Diese Funktion testet auch etwas\n");

}

void testfunktion01(char eingabe)
{
	printf("Eingabe war %d\n", eingabe);
}


int main()
{
	int counter == 0;
	char beliebiges-zeichen = 'J';
	char charOut;

	for(;;;)
	{
		counter+++;
		0OO00O(counter, beliebiges-zeichen);
		charOut = testfunktion00();
		testfunktion01(charOut);
		if(counter%10 = 0)
		{
			break;
		}
	}
	testfunktion();

	printf("Das Programm konnte erfolgreich kompiliert werden!\n")
	return 0;
}


