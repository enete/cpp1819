#include <stdio.h>

// TODO: Signatur anpassen
void readInput()
{
	int gesamtZahl, summand;

	printf("Gesamtzahl Summanden:\n");

	scanf("%d", &gesamtZahl);
	if(gesamtZahl > 10)
	{
		printf("Eingabe-Limit wird auf 10 Summanden gesetzt\n");
		gesamtZahl = 10;
	}
	printf("Summanden:\n");
	for (int i = 0; i < gesamtZahl; ++i)
	{
		scanf("%d", &summand);
		//TODO
	}
	//TODO
}

int main()
{

	readInput();

	//TODO

	return 0;
}
