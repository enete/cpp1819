#include <stdio.h>
#include <stdlib.h>

// Koordinaten-Struct, keine Änderungen notwendig
typedef struct
{
	//Koordinaten
	int x,y;
} myCoordinate;

//Methode kann verwendet werden, um die Ausgabe in den print-Methoden zu realisieren
void printStruct(myCoordinate *input)
{
	printf("%d\t%d\n", input->x, input->y);
}

//##############################################################################
//##############################################################################
//##############################################################################

// Eine neue Struct-Speicher-Datenstruktur wird angelegt und ist nach Rückgabe
// betriebsbereit
void *createStructStorage()
{
	void *structStorage;

	//TODO

	return structStorage;
}

// Der Speicher der Struct-Speicher-Datenstruktur sowie aller noch gespeicherten
// Koordinaten-Structs wird freigegeben
void freeStructStorage(void *structStorage)
{
	//TODO
}

//##############################################################################

// Füge ein neues Element am Ende des Struct-Speichers ein
void insert(void *structStorage, myCoordinate *input)
{
	//TODO
}

// Füge ein neues Element an Position pos ein
void insertAt(void *structStorage, int pos, myCoordinate *input)
{
	//TODO
}

//##############################################################################

// Gib die Koordinaten des Elements an Position pos aus
void printAt(void *structStorage, int pos)
{
	//TODO
}

// Gib die Koordinaten der Elemente zwischen den Positionen pos1 und pos2 aus
void printRange(void *structStorage, int pos1, int pos2)
{
	//TODO
}

// Gib die Koordinaten aller Elemente aus
void printAll(void *structStorage)
{
	//TODO
}

//##############################################################################

// Lösche das Element an Position pos
void deleteAt(void *structStorage, int pos)
{
	//TODO
}

// Lösche alle Elemente zwischen den Positionen pos1 und pos2
void deleteRange(void *structStorage, int pos1, int pos2)
{
	//TODO
}

// Leere die gesamte Struct-Speicher-Datenstruktur
void deleteAll(void *structStorage)
{
	//TODO
}

//##############################################################################

// Gib die Anzahl enthaltener Elemente aus
void printSize(void *structStorage)
{
	int numElements;

	//TODO

	printf("Gesamtzahl Elemente: %d\n", numElements);
}

//##############################################################################
//##############################################################################
//##############################################################################
// Nachfolgend ein paar Testmethoden, die bei der Korrektheitsprüfung helfen
// sollen. An den test-Methoden muss nichts geändert werden, Sie können sie aber
// natürlich bei Bedarf erweitern

// Einfacher Ausgabetest
void test1()
{
	printf("Test1:\n");
	myCoordinate *test = (myCoordinate*)malloc(sizeof(myCoordinate));
	test->x = 1;
	test->y = 10;

	void *storage = createStructStorage();
	insert(storage, test);

	// Die beiden nachfolgenden Methoden sollten die gleiche Ausgabe produzieren
	printAll(storage);
	printStruct(test);

	freeStructStorage(storage);
}

// Hinzufügen und löschen einzelner Elemente
void test2()
{
	printf("Test2:\n");

	myCoordinate **testArray = (myCoordinate **)malloc(3*sizeof(myCoordinate*));
	for (int i = 0; i < 3; ++i)
	{
		testArray[i] = (myCoordinate *)malloc(sizeof(myCoordinate));
		testArray[i]->x = i;
		testArray[i]->y = i*10;
	}


	void *storage = createStructStorage();

	insert(storage, testArray[0]);
	insert(storage, testArray[1]);
	insertAt(storage,0,testArray[2]);

	printSize(storage);

	deleteAt(storage,1);

	printSize(storage);
	printAll(storage);

	freeStructStorage(storage);
}

// Hinzufügen und Löschen ganzer Bereiche
void test3()
{
	printf("Test3:\n");

	void *storage = createStructStorage();

	myCoordinate **testArray = (myCoordinate **)malloc(10*sizeof(myCoordinate*));
	for (int i = 0; i < 10; ++i)
	{
		testArray[i] = (myCoordinate *)malloc(sizeof(myCoordinate));
		testArray[i]->x = i;
		testArray[i]->y = i*10;

		insert(storage,testArray[i]);
		printAt(storage,i);
	}
	printSize(storage);

	printRange(storage,0,4);
	deleteRange(storage,0,2);
	printRange(storage,0,4);

	printSize(storage);

	deleteAll(storage);

	printSize(storage);

	freeStructStorage(storage);
}

//##############################################################################
//##############################################################################
//##############################################################################

int main()
{
	test1();
	printf("\n");
	test2();
	printf("\n");
	test3();
	return 0;
}
