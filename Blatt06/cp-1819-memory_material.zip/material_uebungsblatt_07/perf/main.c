#include <time.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct timespec timespec_t;

void capture_time(timespec_t *t1) {
    clock_gettime(CLOCK_MONOTONIC, t1);
}

timespec_t time_diff (const timespec_t end, const timespec_t start) {
    timespec_t diff;
    if (end.tv_nsec < start.tv_nsec) {
        diff.tv_sec = end.tv_sec - start.tv_sec - 1;
        diff.tv_nsec = 1000000000 + end.tv_nsec - start.tv_nsec;
    } else {
        diff.tv_sec = end.tv_sec - start.tv_sec;
        diff.tv_nsec = end.tv_nsec - start.tv_nsec;
    }
    return diff;
}

double time_to_double (const timespec_t t) {
    double d = (double)t.tv_nsec;
    d /= 1000000000.0;
    d += (double)t.tv_sec;
    return d;
}

int main(int argc, char** args) {
	// your code ...
	return 0;
}
