#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>


int main(int argc, char** argv) {
	svector_t *name_list = svector_create();
	svector_init(name_list);
	svector_append(name_list, "Franz Meier");
	svector_append(name_list, "Tobias Schroeder");
	svector_append(name_list, "Anne Kraus");
	svector_append(name_list, "Tom Hook");
	svector_print(name_list);
	svector_destroy(name_list);
	return 0;
}
