#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#define SVECTOR_INITIAL_CAPACITY 3;

typedef struct {
	unsigned int size;
	unsigned int capacity;
	char** data;
} svector_t;

svector_t* svector_create() {
	return malloc(sizeof(svector_t));
}

void svector_init(svector_t* vector) {
	vector->size = 0;
	vector->capacity = SVECTOR_INITIAL_CAPACITY;
	vector->data = (char**)malloc(sizeof(char*) * vector->capacity);
}

void svector_append(svector_t* vector, char* elem) {
	// Allocate more memory
	if (vector->size == vector->capacity) {
		vector->capacity = vector->capacity * 2;
		char** data = (char**)malloc(sizeof(char*) * vector->capacity);
		for (size_t i = 0; i < vector->size; ++i) {
			data[i] = vector->data[i];
		}
		free(vector->data);
		vector->data = data;
	}
	char* elem_copy = (char*)malloc(sizeof(char) * strlen(elem) + 1);
	strcpy(elem_copy, elem);
	vector->data[vector->size] = elem_copy;
	++vector->size;
}

void svector_destroy(svector_t* vector) {
	for (unsigned int i = 0; i < vector->size; ++i) {
		free(vector->data[i]);
	}
	free(vector->data);
}

void svector_print(svector_t* vector) {
	printf("\tvector size:\t%d\n", vector->size);
	printf("\tvector capacity:\t%d\n", vector->capacity);
	for (unsigned int i = 0; i < vector->size; ++i) {
		printf("\tvector elem: %d\t value: %s\n", i, vector->data[i]);
	}
}

int main(int argc, char** argv) {
	svector_t *name_list = svector_create();
	svector_init(name_list);
	svector_append(name_list, "Franz Meier");
	svector_append(name_list, "Tobias Schröder");
	svector_append(name_list, "Anne Kraus");
	svector_append(name_list, "Tom Hook");
	svector_print(name_list);
	svector_destroy(name_list);
	return 0;
}
