#!/bin/bash
#
CC="$(which gcc)"
CFLAGS="-g3 -Wall"
CPPFLAGS="-DDEBUG"
LDFLAGS=""

set -x
${CC} ${CPPFLAGS} ${CFLAGS} ${LDFLAGS} -lm -o ./program ./main_solution.c
set +x
