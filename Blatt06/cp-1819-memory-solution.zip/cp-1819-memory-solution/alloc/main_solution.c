#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

int* alloc_array(size_t dt, size_t dx, size_t dy, size_t dz) {
	int (*values)[dx][dy][dz] = malloc(sizeof(*values) * dt); // So do you think you know C?
	for(size_t t = 0; t < dt; ++t) {
		for(size_t x = 0; x < dx; ++x) {
			for(size_t y = 0; y < dy; ++y) {
				for(size_t z = 0; z < dz; ++z) {
					values[t][x][y][z] = t*1000 + x*100 + y*10 + z*1;
//					printf("[%ld:%ld:%ld:%ld] = %04d\n", t, x, y, z, values[t][x][y][z]);
				}
			}
		}
	}
	return (int*) values;
}

int* alloc_mem(size_t dt, size_t dx, size_t dy, size_t dz) {
	int* values = (int*) malloc(sizeof(*values) * dt * dx * dy * dz);
	for(size_t t = 0; t < dt; ++t) {
		for(size_t x = 0; x < dx; ++x) {
			for(size_t y = 0; y < dy; ++y) {
				for(size_t z = 0; z < dz; ++z) {
					size_t idx = dx*dy*dz*t + dy*dz*x + dz*y + z; // hier explodiert das Gehirn
					values[idx] = t*1000 + x*100 + y*10 + z*1;
//					printf("[%ld:%ld:%ld:%ld] = %04d\n", t, x, y, z, values[idx]);
				}
			}
		}
	}
	return values;
}

int main (int argc, char** argv) {
	// Allocation
	size_t dt = 10;
	size_t dx = 10;
	size_t dy = 10;
	size_t dz = 10;
	int* values_a = alloc_array(dt, dx, dy, dz);
	int* values_p = alloc_mem(dt, dx, dy, dz);

	// Verification
	for (size_t i = 0; i < dt*dx*dy*dz; ++i) {
		printf("%03ld = %04d %04d\n", i, values_a[i], values_p[i]);
		assert(values_a[i] == values_p[i]);
	}

	// Cleanup
	free(values_a);
	free(values_p);
  return 0;
}
