#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>


typedef struct timespec timespec_t;

inline void capture_time(timespec_t *t1);

void capture_time(timespec_t *t1) {
    clock_gettime(CLOCK_MONOTONIC, t1);
}

timespec_t time_diff (const timespec_t end, const timespec_t start) {
    timespec_t diff;
    if (end.tv_nsec < start.tv_nsec) {
        diff.tv_sec = end.tv_sec - start.tv_sec - 1;
        diff.tv_nsec = 1000* 1000 * 1000 + end.tv_nsec - start.tv_nsec;
    } else {
        diff.tv_sec = end.tv_sec - start.tv_sec;
        diff.tv_nsec = end.tv_nsec - start.tv_nsec;
    }
    return diff;
}

double time_to_double (const timespec_t t) {
    double d = (double)t.tv_nsec;
	  d /= 1000*1000*1000.0;
    d += (double)t.tv_sec * 1000*1000*1000;
    return d;
}


double mean(size_t size, double* data) {
	double sum = 0;
	for (size_t i = 0; i < size; ++i) {
			sum += data[i];
	}
	return sum / size;
}

void init(size_t size, int array[size]) {
	for (int i = 0; i < size; ++i) {
		array[i] = 1;
	}
}

int main(int argc, char** args) {
	timespec_t t0, t1;
	size_t sizes[] = {100, 1000, 10000, 100000, 1000000};
	size_t iterations = 10000;


	for (int j = 0; j < 5; ++j) {
		size_t size = sizes[j];

		double *runtime_none = malloc(iterations * sizeof(double));
		if( runtime_none == NULL ) {
			printf("Error: %s\n", strerror(errno));
			exit(0);
		}
		double *runtime_stack = malloc(iterations * sizeof(double));
		if( runtime_stack == NULL ) {
			printf("Error: %s\n", strerror(errno));
			exit(0);
		}
		double *runtime_malloc = malloc(iterations * sizeof(double));
		if( runtime_malloc == NULL ) {
			printf("Error: %s\n", strerror(errno));
			exit(0);
		}
		double *runtime_calloc = malloc(iterations * sizeof(double));
		if( runtime_calloc == NULL ) {
			printf("Error: %s\n", strerror(errno));
			exit(0);
		}

		for (int i = 0; i < iterations; ++i) {
			{
				capture_time(&t0);
				capture_time(&t1);
				runtime_none[i] = time_to_double(time_diff(t1, t0));
			}

			{
				capture_time(&t0);
				int values[size];
				capture_time(&t1);
				runtime_stack[i] = time_to_double(time_diff(t1, t0));
			}

			{
				capture_time(&t0);
				int * values = malloc(sizeof(*values) * size);
				capture_time(&t1);
				runtime_malloc[i] = time_to_double(time_diff(t1, t0));
				if( values == NULL ) {
					printf("Error: %s\n", strerror(errno));
					exit(1);
				}
				free(values);
				values = NULL;
			}

			{
				capture_time(&t0);
				int* values = calloc(sizeof(*values), size);
				capture_time(&t1);
				runtime_calloc[i] = time_to_double(time_diff(t1, t0));
				if( values == NULL ) {
					printf("Error: %s\n", strerror(errno));
					exit(1);
				}
				free(values);
				values = NULL;
			}
		}

		double mean_none = mean(iterations, runtime_none);
		double mean_stack = mean(iterations, runtime_stack) - mean_none;
		double mean_malloc = mean(iterations, runtime_malloc) - mean_none;
		double mean_calloc = mean(iterations, runtime_calloc) - mean_none;

//		printf("time\nmeasurement %0.12f us\nstack %0.12f us\nmalloc %0.12f\ncalloc %0.12f us\n", mean_none*1000*1000, mean_stack*1000*1000, mean_malloc*1000*1000, mean_calloc*1000*1000);
		printf("measurement time %0.12f microseconds\n", mean_none*1000*1000);
		printf("malloc slow down factor (compared to stack): %0.12f\ncalloc slow down factor (compared to malloc) %0.12f\ninitialization rate %0.0f ints/sec\n",
				mean_malloc/mean_stack, 
				mean_calloc/mean_malloc, 
				size / mean_calloc);

		free(runtime_none);
		free(runtime_stack);
		free(runtime_malloc);
		free(runtime_calloc);
	}

	return 0;
}
